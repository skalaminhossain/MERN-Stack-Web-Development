import { Univercitys } from "./univercity.js";

Univercitys.map((items , index)=>{
    let univercityName = items.name
    let univercityWebsite = items.website
    console.log(`univercitys name is ${univercityName}`);
    console.log(`univercitys website is ${univercityWebsite}`)

    
})