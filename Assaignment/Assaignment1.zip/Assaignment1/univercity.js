// Univercity name , website and ranking list

let Univercitys = [
    {
        name : 'Dhaka Univercity',
        website : 'web.du.ac.bd',
        ranking : 1
    },
    {
        name : 'University of Rajshahi',
        website : 'www.ru.ac.bd',
        ranking : 2
    },
    {
        name : 'Bangladesh Agricultural University',
        website : 'www.bau.edu.bd',
        ranking : 3
    },
    {
        name : 'Bangladesh University of Engineering & Technology',
        website : 'www.buet.ac.bd',
        ranking : 4
    },
    {
        name : 'University of Chittagong',
        website : '	www.cu.ac.bd',
        ranking : 5
    },
    {
        name : 'Shahjalal University of Science & Technology',
        website : 'www.sust.edu',
        ranking : 6
    },
    {
        name : 'Bangabandhu Sheikh Mujib Medical University',
        website : 'www.bsmmu.edu.bd',
        ranking : 7
    },
    {
        name : 'National University',
        website : '	www.nu.edu.bd',
        ranking : 8
    },
    {
        name : 'Islamic Arabic University',
        website : 'www.iau.edu.bd',
        ranking : 9
    },
    {
        name : 'Sheikh Hasina University',
        website : 'https://shubd.net/',
        ranking : 10
    },

]

export  {Univercitys};